const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Temporary in-memory storage
let users = [];
let products = [];
let receipts = [];
let deliveries = [];
let transfers = [];

module.exports = { users, products, receipts, deliveries, transfers };

// Routes
app.use("/auth", require("./routes/authRoutes"));
app.use("/stock", require("./routes/stockRoutes"));


app.listen(5000, () => console.log("Server running on port 5000"));
