import React from "react";
import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <div style={{
      width: "220px",
      backgroundColor: "#222",
      color: "#fff",
      height: "100vh",
      padding: "20px"
    }}>
      <h3>StockMaster</h3>
      <ul style={{ listStyle: "none", padding: 0 }}>
        <li><Link to="/dashboard" style={{ color: "#fff", textDecoration: "none" }}>Dashboard</Link></li>
        <li><Link to="/products" style={{ color: "#fff", textDecoration: "none" }}>Products</Link></li>
        <li><Link to="/receipts" style={{ color: "#fff", textDecoration: "none" }}>Receipts</Link></li>
        <li><Link to="/delivery" style={{ color: "#fff", textDecoration: "none" }}>Delivery</Link></li>
        <li><Link to="/transfers" style={{ color: "#fff", textDecoration: "none" }}>Transfers</Link></li>
        <li><Link to="/history" style={{ color: "#fff", textDecoration: "none" }}>History</Link></li>

        <li
          style={{ marginTop: "20px", cursor: "pointer", color: "red" }}
          onClick={() => {
            localStorage.removeItem("token");
            window.location.href = "/";
          }}
        >
          Logout
        </li>
      </ul>
    </div>
  );
}
