// src/components/Header.js
import React from "react";

const Header = ({ title }) => {
  return (
    <div className="d-flex justify-content-between align-items-center mb-4">
      <h3>{title}</h3>
      <div>
        <span className="me-3">Hello, Manager</span>
      </div>
    </div>
  );
};

export default Header;
