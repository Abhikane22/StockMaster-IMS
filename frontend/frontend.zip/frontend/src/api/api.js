// src/api/api.js
import axios from "axios";

const BACKEND = "http://localhost:5000/api"; // change when backend is ready

const api = axios.create({
  baseURL: BACKEND,
  timeout: 10000,
});

// helper: if backend unavailable use localStorage mock
export async function fetchProducts() {
  try {
    const res = await api.get("/products");
    return res.data;
  } catch (err) {
    // fallback to localStorage
    const raw = localStorage.getItem("products");
    return raw ? JSON.parse(raw) : [];
  }
}

export async function createProduct(payload) {
  try {
    const res = await api.post("/products", payload);
    return res.data;
  } catch (err) {
    const products = await fetchProducts();
    const newProd = { id: Date.now().toString(), ...payload };
    products.push(newProd);
    localStorage.setItem("products", JSON.stringify(products));
    return newProd;
  }
}

export async function updateProduct(id, payload) {
  try {
    const res = await api.put(`/products/${id}`, payload);
    return res.data;
  } catch (err) {
    const products = await fetchProducts();
    const updated = products.map(p => p.id === id ? { ...p, ...payload } : p);
    localStorage.setItem("products", JSON.stringify(updated));
    return updated.find(p => p.id === id);
  }
}

export async function deleteProduct(id) {
  try {
    const res = await api.delete(`/products/${id}`);
    return res.data;
  } catch (err) {
    const products = (await fetchProducts()).filter(p => p.id !== id);
    localStorage.setItem("products", JSON.stringify(products));
    return { success: true };
  }
}

export default api;
