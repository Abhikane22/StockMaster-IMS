import React, { useEffect, useState } from "react";
import axios from "axios";

export default function History() {
  const [history, setHistory] = useState([]);

  const loadHistory = async () => {
    const res = await axios.get("http://localhost:5000/stock/history");

    const combined = [
      ...res.data.receipts.map(r => ({ type: "IN", ...r })),
      ...res.data.deliveries.map(d => ({ type: "OUT", ...d })),
      ...res.data.transfers.map(t => ({ type: "Transfer", ...t })),
    ];

    setHistory(combined.reverse());
  };

  useEffect(() => {
    loadHistory();
  }, []);

  return (
    <div className="container mt-4">
      <h3>History</h3>

      <table className="table table-striped">
        <thead>
          <tr>
            <th>Type</th>
            <th>Product ID</th>
            <th>Qty</th>
            <th>From</th>
            <th>To</th>
          </tr>
        </thead>
        <tbody>
          {history.map((h, index) => (
            <tr key={index}>
              <td>{h.type}</td>
              <td>{h.productId}</td>
              <td>{h.qty}</td>
              <td>{h.from || "-"}</td>
              <td>{h.to || "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
