import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Signup() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const submit = async (e) => {
    e.preventDefault();
    const response = await axios.post("http://localhost:5000/auth/register", form);
    alert(response.data.message);
    if (response.data.status) navigate("/");
  };

  return (
    <div style={{ marginTop: "80px", textAlign: "center" }}>
      <h2>Signup</h2>
      <form onSubmit={submit} style={{ width: "300px", margin: "auto" }}>
        <input placeholder="Name" className="form-control" onChange={(e)=> setForm({...form,name:e.target.value})} required /><br/>
        <input placeholder="Email" type="email" className="form-control" onChange={(e)=> setForm({...form,email:e.target.value})} required /><br/>
        <input placeholder="Password" type="password" className="form-control" onChange={(e)=> setForm({...form,password:e.target.value})} required /><br/>
        <button className="btn btn-primary" type="submit">Signup</button>
      </form>
    </div>
  );
}
