import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Transfers() {
  const [products, setProducts] = useState([]);
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const locations = ["HQ", "Warehouse-1", "Warehouse-2", "Store-1", "Store-2"];

  const fetchProducts = async () => {
    const res = await axios.get("http://localhost:5000/stock/products");
    setProducts(res.data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const transferStock = async () => {
    try {
      await axios.post("http://localhost:5000/stock/transfers", {
        productId: Number(productId),
        qty: Number(qty),
        from,
        to,
      });

      setQty("");
      setFrom("");
      setTo("");
      alert("Transfer Completed Successfully!");
      fetchProducts();
    } catch (err) {
      alert(err.response?.data?.message || "Error processing transfer");
    }
  };

  return (
    <div className="container mt-4">
      <h3>Transfer Stock</h3>

      <div className="card p-3 mb-3">
        <select className="form-control my-2" onChange={(e) => setProductId(e.target.value)}>
          <option>Select Product</option>
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name} (Available: {p.quantity})
            </option>
          ))}
        </select>

        <input
          type="number"
          placeholder="Quantity"
          className="form-control my-2"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
        />

        <select className="form-control my-2" onChange={(e) => setFrom(e.target.value)}>
          <option>From Location</option>
          {locations.map((loc) => (
            <option key={loc}>{loc}</option>
          ))}
        </select>

        <select className="form-control my-2" onChange={(e) => setTo(e.target.value)}>
          <option>To Location</option>
          {locations.map((loc) => (
            <option key={loc}>{loc}</option>
          ))}
        </select>

        <button className="btn btn-warning" onClick={transferStock}>
          Transfer Stock
        </button>
      </div>
    </div>
  );
}
