import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Receipts() {
  const [products, setProducts] = useState([]);
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState("");

  // Fetch product list
  const fetchProducts = async () => {
    const res = await axios.get("http://localhost:5000/stock/products");
    setProducts(res.data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const addStock = async () => {
    try {
      await axios.post("http://localhost:5000/stock/receipts", {
        productId: Number(productId),
        qty: Number(qty),
      });

      setQty("");
      alert("Stock Added Successfully!");
      fetchProducts();
    } catch (err) {
      alert(err.response?.data?.message || "Error processing receipt");
    }
  };

  return (
    <div className="container mt-4">
      <h3>Receipts (Add Stock)</h3>

      <div className="card p-3 mb-3">
        <select
          className="form-control my-2"
          onChange={(e) => setProductId(e.target.value)}
        >
          <option>Select Product</option>
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>

        <input
          type="number"
          placeholder="Quantity to Add"
          className="form-control my-2"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
        />

        <button className="btn btn-success" onClick={addStock}>
          Add Stock
        </button>
      </div>
    </div>
  );
}
