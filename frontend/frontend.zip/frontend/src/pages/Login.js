import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [isSignup, setIsSignup] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const navigate = useNavigate();

  const handleSubmit = async () => {
    try {
      if (isSignup) {
        await axios.post("http://localhost:5000/auth/signup", form);
        alert("Signup Success! Please Login.");
        setIsSignup(false);
      } else {
        const res = await axios.post("http://localhost:5000/auth/login", form);
        localStorage.setItem("token", res.data.token);
        navigate("/dashboard");
      }
    } catch (err) {
      alert(err.response?.data?.message || "Error occurred");
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center" style={{ height: "100vh" }}>
      <div className="card p-4 w-25">
        <h3 className="text-center">{isSignup ? "Signup" : "Login"}</h3>

        {isSignup && (
          <input
            type="text"
            placeholder="Name"
            className="form-control my-2"
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        )}

        <input
          type="email"
          placeholder="Email"
          className="form-control my-2"
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          type="password"
          placeholder="Password"
          className="form-control my-2"
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />

        <button className="btn btn-primary w-100 mt-2" onClick={handleSubmit}>
          {isSignup ? "Signup" : "Login"}
        </button>

        <p className="text-center mt-3" style={{ cursor: "pointer" }} onClick={() => setIsSignup(!isSignup)}>
          {isSignup ? "Already have an account? Login" : "Create new account"}
        </p>
      </div>
    </div>
  );
}
