import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {
  const [products, setProducts] = useState([]);

  const loadProducts = async () => {
    try {
      const res = await axios.get("http://localhost:5000/stock/products");
      setProducts(res.data);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const totalStock = products.reduce((sum, p) => sum + p.quantity, 0);
  const lowStock = products.filter((p) => p.quantity < 5).length;

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">📊 Dashboard Overview</h2>

      {/* STAT CARDS */}
      <div className="row mb-4">
        <div className="col-md-4">
          <div className="card shadow p-4 text-center">
            <h5>Total Product Categories</h5>
            <h1 style={{ color: "#007bff" }}>{products.length}</h1>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card shadow p-4 text-center">
            <h5>Total Stock Units</h5>
            <h1 style={{ color: "#28a745" }}>{totalStock}</h1>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card shadow p-4 text-center">
            <h5>Low Stock Items</h5>
            <h1 style={{ color: "red" }}>{lowStock}</h1>
          </div>
        </div>
      </div>

      {/* RECENT PRODUCTS TABLE */}
      <div className="card shadow p-3">
        <h4 className="mb-3">📦 Recent Products</h4>
        <table className="table table-striped">
          <thead style={{ backgroundColor: "#eee" }}>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            {products.slice(-5).reverse().map((p) => (
              <tr key={p.id}>
                <td>{p.id}</td>
                <td>{p.name}</td>
                <td>{p.quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
