import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Delivery() {
  const [products, setProducts] = useState([]);
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState("");

  // Load products
  const fetchProducts = async () => {
    const res = await axios.get("http://localhost:5000/stock/products");
    setProducts(res.data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const removeStock = async () => {
    try {
      await axios.post("http://localhost:5000/stock/delivery", {
        productId: Number(productId),
        qty: Number(qty),
      });

      setQty("");
      alert("Delivery Processed (Stock removed)");
      fetchProducts();
    } catch (err) {
      alert(err.response?.data?.message || "Error processing delivery");
    }
  };

  return (
    <div className="container mt-4">
      <h3>Delivery (Remove Stock)</h3>

      <div className="card p-3 mb-3">
        <select
          className="form-control my-2"
          onChange={(e) => setProductId(e.target.value)}
        >
          <option>Select Product</option>
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name} (Current: {p.quantity})
            </option>
          ))}
        </select>

        <input
          type="number"
          placeholder="Quantity to Remove"
          className="form-control my-2"
          value={qty}
          onChange={(e) => setQty(e.target.value)}
        />

        <button className="btn btn-danger" onClick={removeStock}>
          Remove Stock
        </button>
      </div>
    </div>
  );
}
