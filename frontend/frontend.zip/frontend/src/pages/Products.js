import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [name, setName] = useState("");
  const [quantity, setQuantity] = useState("");

  // Fetch products initially
  const fetchProducts = async () => {
    const res = await axios.get("http://localhost:5000/stock/products");
    setProducts(res.data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Add product handler
  const addProduct = async () => {
    try {
      await axios.post("http://localhost:5000/stock/products/add", {
        name,
        quantity: Number(quantity),
      });

      setName("");
      setQuantity("");
      fetchProducts();   // Refresh list
      alert("Product Added!");
    } catch (err) {
      alert("Error adding product");
    }
  };

  return (
    <div className="container mt-4">
      <h3>Products</h3>

      <div className="card p-3 mb-3">
        <h5>Add New Product</h5>
        <input
          type="text"
          placeholder="Product Name"
          className="form-control my-2"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <input
          type="number"
          placeholder="Initial Quantity"
          className="form-control my-2"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
        />

        <button className="btn btn-primary" onClick={addProduct}>
          Add Product
        </button>
      </div>

      <table className="table table-dark table-bordered">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Qty</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p, index) => (
            <tr key={p.id}>
              <td>{index + 1}</td>
              <td>{p.name}</td>
              <td>{p.quantity}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
