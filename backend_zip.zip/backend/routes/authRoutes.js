const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

let { users } = require("../server");

// Signup API
router.post("/signup", async (req, res) => {
  const { name, email, password } = req.body;

  const exists = users.find((u) => u.email === email);
  if (exists) {
    return res.status(400).json({ message: "User already exists" });
  }

  const hash = await bcrypt.hash(password, 10);
  users.push({ name, email, password: hash });

  return res.json({ message: "Signup Successful" });
});

// Login API
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const user = users.find((u) => u.email === email);
  if (!user) return res.status(404).json({ message: "User not found" });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ message: "Incorrect password" });

  const token = jwt.sign({ email }, "SECRET_KEY", { expiresIn: "1h" });

  return res.json({ message: "Login Successful", token });
});

module.exports = router;
    