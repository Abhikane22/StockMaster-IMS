const express = require("express");
const router = express.Router();

let { products, receipts, deliveries, transfers } = require("../server");

// Add new product
router.post("/products/add", (req, res) => {
  const { name, quantity } = req.body;
  products.push({ id: Date.now(), name, quantity });
  return res.json({ message: "Product Added", products });
});

// Get products list
router.get("/products", (req, res) => {
  return res.json(products);
});

// Add stock (Receipt)
router.post("/receipts", (req, res) => {
  const { productId, qty } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ message: "Product not found" });

  product.quantity += qty;
  receipts.push({ id: Date.now(), productId, qty, type: "IN" });

  return res.json({ message: "Stock added", products });
});

// Delivery - remove stock
router.post("/delivery", (req, res) => {
  const { productId, qty } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ message: "Product not found" });
  if (product.quantity < qty) return res.status(400).json({ message: "Not enough stock" });

  product.quantity -= qty;
  deliveries.push({ id: Date.now(), productId, qty, type: "OUT" });

  return res.json({ message: "Delivery processed", products });
});

// Transfer stock
router.post("/transfers", (req, res) => {
  const { productId, qty, from, to } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ message: "Product not found" });

  if (product.quantity < qty) return res.status(400).json({ message: "Not enough stock" });

  product.quantity -= qty;
  transfers.push({ id: Date.now(), productId, qty, from, to });

  return res.json({ message: "Transfer complete", products });
});

// History logs
router.get("/history", (req, res) => {
  return res.json({ receipts, deliveries, transfers });
});

module.exports = router;
